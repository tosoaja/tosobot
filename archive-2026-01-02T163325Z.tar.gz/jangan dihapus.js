/*
    # Credits By WazzOfc
  https://wa.me/6287822788608
  
 NO HAPUS CREDITS!!!!!!! HARGAI PEMBUATNYA
*/
//𝙎𝘾 𝙄𝙉𝙄 𝙁𝙍𝙀𝙀 100% 𝙆𝘼𝙇𝙊 𝘼𝘿𝘼 𝙔𝘼𝙉𝙂 𝙉𝙂𝙀𝙅𝙐𝘼𝙇 𝘽𝙀𝙎𝙊𝙆 𝙈𝘼𝙈𝘼𝙆𝙉𝙔𝘼 𝙈𝘼𝙏𝙄

TQTO
© jarr Official 
- WazzOfc
- Allah
- bapak
- ibu
- semuanya

Base
- © jarr